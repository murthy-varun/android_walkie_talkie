package org.hsc.media;

public interface LineListener {

}
