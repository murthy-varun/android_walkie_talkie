package org.hsc.media;

public interface Clip {

}
