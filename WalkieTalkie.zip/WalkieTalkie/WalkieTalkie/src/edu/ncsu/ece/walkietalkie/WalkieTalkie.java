package edu.ncsu.ece.walkietalkie;

import java.net.Socket;

import edu.ncsu.ece.walkietalkie.R;
import edu.ncsu.ece.walkietalkie.WalkieTalkieEngine;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.InputType;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.ImageButton;




public class WalkieTalkie extends Activity{
    
	WalkieTalkieEngine m_WalkieTalkieEngine;
	int m_CurrentTimer = 0;
	// Need handler for callbacks to the UI thread
	final Handler mHandler = new Handler();
	
	private static final String TAG = "WalkieTalkieEngine";
	
	/* Following the menu item constants which will be used for menu creation */
	public static final int LOGIN_MENU_ID = Menu.FIRST;
	public static final int REGISTER_MENU_ITEM = LOGIN_MENU_ID + 1;
	public static final int UNREGISTER_MENU_ITEM = LOGIN_MENU_ID + 2;
	public static final int EXIT_MENU_ITEM = LOGIN_MENU_ID + 3;
	
	AlertDialog m_AlertDlg = null;


	ImageButton start, stop;
	EditText show_text;
	
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	
    	
    	super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        Log.e(TAG, "onCreate called");
        
        start = (ImageButton) findViewById(R.id.Button01);
        stop = (ImageButton) findViewById(R.id.Button02);
        show_text = (EditText) findViewById(R.id.EditText01);
        
        
        start.setEnabled(false); // Disable START button initially
        stop.setEnabled(false); // Disable STOP button initially        
        
        show_text.setSingleLine();
        show_text.setInputType(InputType.TYPE_NULL);
      
        m_CurrentTimer = 1;
        
        m_WalkieTalkieEngine = new WalkieTalkieEngine(get_local_ip_addr());
        
        m_WalkieTalkieEngine.StartEngine();
        
        Integer tmp = new Integer(m_WalkieTalkieEngine.GetState());
        Log.e(TAG, tmp.toString());
        start.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				show_text.setText("Walkie-Talkie Engine Started");

				start.setEnabled(false); // Disable START button initially
		        stop.setEnabled(true); // Enable STOP button initially
		        
				boolean sipsend_status = m_WalkieTalkieEngine.sipsend();
				if(sipsend_status) {
					show_text.setText("You can talk now.");
				}
				else {
					show_text.setText("Talk failed");
				}
				//show_text.setText("Engine Started");
			}
        });
        
        stop.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				//show_text.setText("Walkie-Talkie Engine Stopped");
				
				stop.setEnabled(false); // Disable STOP button initially
		        start.setEnabled(true); // Enable START button initially
	
		        
				m_WalkieTalkieEngine.stopsip();
				show_text.setText("Talk Finished");
			}
        	
        });
    }
	
	public Context getUIContext() {
		return this;
	}
	
	public String get_local_ip_addr() {
		String ipAddress = null;
		try
		{
			Socket socket = new Socket("www.ncsu.edu", 80);
			ipAddress = socket.getLocalAddress().toString();
		}
		catch(Exception e)
		{
			Log.i(TAG, e.getMessage());
		}
		
		
		Log.e(TAG, "local ip = "+ipAddress);
		return ipAddress;
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode,
			 Intent extras) {
		
		switch(requestCode)
		{
			case Constants.LOGIN_ACTIVITY:
			{
				boolean result = m_WalkieTalkieEngine.login();
				if(result == true){
					show_text.setText("Login Successful");
					
					}
				else{
					show_text.setText("Login Failed");
					m_AlertDlg = new AlertDialog.Builder(this)
					.setMessage("Login Failed.")
					.setTitle("Walkie Talkie")					
					.setCancelable(true)
					.setPositiveButton("OK", new DialogInterface.OnClickListener() {
						
						@Override
						public void onClick(DialogInterface dialog, int which) {
							// TODO Auto-generated method stub
							dialog.cancel();
						}
					})
					.show();

					try
					{
						m_AlertDlg.wait(10);	
					}
					catch (Exception e1)
					{
						
					};
				}
				break;
			}
			case Constants.REGISTER_ACTIVITY:
			{
				// TODO: Check state if logged in else alert notif
				boolean result = m_WalkieTalkieEngine.register(3600);
				if(result == true){
					show_text.setText("Registration Successful");}
				else{
					show_text.setText("Registration Failed");
					show_text.setText("Login Failed");
					m_AlertDlg = new AlertDialog.Builder(this)
					.setMessage("Registration Failed")
					.setTitle("Walkie Talkie")					
					.setCancelable(true)
					.setPositiveButton("OK", new DialogInterface.OnClickListener() {
						
						@Override
						public void onClick(DialogInterface dialog, int which) {
							// TODO Auto-generated method stub
							dialog.cancel();
						}
					})
					.show();

					try
					{
						m_AlertDlg.wait(10);	
					}
					catch (Exception e1)
					{
						
					};
				}
				start.setEnabled(true); // Enable START button				
				break;
			}
		}
		
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		boolean result = super.onCreateOptionsMenu(menu);
		
		// Create and add new menu items.
		MenuItem itemLogin = menu.add(0, LOGIN_MENU_ID, Menu.NONE, "Login");
		MenuItem itemReg = menu.add(0, REGISTER_MENU_ITEM, Menu.NONE, "Register");
		MenuItem itemUnReg = menu.add(0, UNREGISTER_MENU_ITEM, Menu.NONE, "Un-Register");
		MenuItem itemExit = menu.add(0, EXIT_MENU_ITEM, Menu.NONE, "Exit");
		
		// Assign icons		
		itemLogin.setIcon(R.drawable.barcode);
		itemReg.setIcon(R.drawable.sun);
		itemUnReg.setIcon(R.drawable.flash);
		itemExit.setIcon(R.drawable.exit);
		
		return result;		
	}

	@Override
	public boolean onPrepareOptionsMenu(Menu menu) {
		boolean result = super.onPrepareOptionsMenu(menu);
		
		if (m_WalkieTalkieEngine.GetState() == Constants.INIT)
		{
			menu.findItem(REGISTER_MENU_ITEM).setVisible(false);
			menu.findItem(UNREGISTER_MENU_ITEM).setVisible(false);
			menu.findItem(LOGIN_MENU_ID).setVisible(true);
		}
		if (m_WalkieTalkieEngine.GetState() == Constants.LOGGED_IN)
		{
			menu.findItem(LOGIN_MENU_ID).setVisible(false);
			menu.findItem(UNREGISTER_MENU_ITEM).setVisible(false);
			menu.findItem(REGISTER_MENU_ITEM).setVisible(true);
		}
		if (m_WalkieTalkieEngine.GetState() == Constants.REGISTERED)
		{
			menu.findItem(LOGIN_MENU_ID).setVisible(false);
			menu.findItem(REGISTER_MENU_ITEM).setVisible(false);
			menu.findItem(UNREGISTER_MENU_ITEM).setVisible(true);
		}
		
		return result;
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		return false;
	}
	
	@Override
	public boolean onKeyUp(int keyCode, KeyEvent event) {
		return false;
	}

	@Override	
	public boolean onOptionsItemSelected(MenuItem item) {
		boolean result = super.onOptionsItemSelected(item);
		Intent intent = null;
		
		switch (item.getItemId()) {
			case EXIT_MENU_ITEM: 
			{
				if(m_WalkieTalkieEngine.GetState()!=0)
					m_WalkieTalkieEngine.bye();
				onDestroy();
				onStop();
				this.finish();
				break;
			}
			
			
			case LOGIN_MENU_ID:
			{
				try{
					intent = new Intent(this, LoginUI.class);
					startActivityForResult(intent, Constants.LOGIN_ACTIVITY);
				}catch(ActivityNotFoundException e){
					m_AlertDlg = new AlertDialog.Builder(this)
					.setMessage("Problem launching Login page.")
					.setTitle("Walkie Talkie")					
					.setCancelable(true)
					.show();

					try
					{
						m_AlertDlg.wait(10);	
					}
					catch (Exception e1)
					{
						
					};
				}
				break;
			}
			
			case REGISTER_MENU_ITEM:
			{
				try{
					intent = new Intent(this, RegisterUI.class);
					startActivityForResult(intent, Constants.REGISTER_ACTIVITY);
				}catch(ActivityNotFoundException e){
					m_AlertDlg = new AlertDialog.Builder(this)
					.setMessage("Problem launching Register page.")
					.setTitle("Walkie Talkie")					
					.setCancelable(true)
					.show();

					try
					{
						m_AlertDlg.wait(10);	
					}
					catch (Exception e1)
					{
						
					};
				}
				
				break;
			}
			
			case UNREGISTER_MENU_ITEM:
			{
				boolean res = m_WalkieTalkieEngine.register(0);
				if(res == true){
					show_text.setText("Unregistration Successful");}
				else{
					show_text.setText("Unregistration Failed");}
				start.setEnabled(false);
				
				break;				
			}
		}
		
		return result;
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();	
		Log.e(TAG,"onDestroy Called.");
		if(m_WalkieTalkieEngine.GetState()!= Constants.INIT)
			m_WalkieTalkieEngine.bye();
		m_WalkieTalkieEngine.setState(Constants.INIT);
		WalkieTalkieEngine.m_groupNum = null;
		WalkieTalkieEngine.m_password = null;
		WalkieTalkieEngine.m_server_addr = null;
		WalkieTalkieEngine.m_userName = null;	
	}

	@Override
	protected void onStop() {	
		super.onStop();
		Log.e(TAG, "onStop Called");
	}

	@Override
	protected void onPause() {
		super.onPause();
		Log.e(TAG, "onPause Called");
		// TODO Auto-generated method stub
	}

	@Override
	protected void onRestart() {
		super.onRestart();
		Log.e(TAG, "onRestart Called");
		// TODO Auto-generated method stub
	}

	@Override
	protected void onResume() {
		super.onResume();
		Log.e(TAG, "onResume Called");
		// TODO Auto-generated method stub
	}

	@Override
	protected void onStart() {
		super.onStart();
		Log.e(TAG, "onStart Called");
		// TODO Auto-generated method stub
	}
	
	
	
}