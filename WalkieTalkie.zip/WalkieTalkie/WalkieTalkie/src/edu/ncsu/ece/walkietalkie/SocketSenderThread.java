package edu.ncsu.ece.walkietalkie;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

import android.util.Log;

import org.hsc.net.RtpPacket;
import org.hsc.net.RtpSocket;


public class SocketSenderThread implements Runnable{

	public SocketSenderThread(String daddr,
			int dport, Object ssMonitor) {
		super();		
		this.daddr = daddr;
		this.dport = dport;
		ss_monitor = ssMonitor;
		
		init();
	}
	
	private void init()
	{
		DatagramSocket src_socket = null;
		try {
			src_socket = new DatagramSocket();			
			
			Log.i(TAG, "init: dest addr"+InetAddress.getByName(daddr)+" port: "+dport);
			rtp_socket = new RtpSocket(src_socket, InetAddress.getByName(daddr),dport);
		} 
		catch (UnknownHostException e) {			
			e.printStackTrace();
		}
		catch (SocketException e) {
			Log.i(TAG, "Socket cannot be opened");
			e.printStackTrace();
		}
	}

	private InputStream audio_input;
	private String daddr;
	private int dport;
	
	private static final String TAG = "WalkieTalkieEngine";
	
	public static boolean all_files_sent = true;
	
	RtpSocket rtp_socket = null;
	
	Object ss_monitor = new Object();
	
	@Override
	public void run() {
		int sample_rate = 8000;
		int sample_size = 1;
		int frame_size = Constants.PKT_SIZE;
		int payload_type = 0;		
		boolean running = true;
		int last_file_sent = 0;
		int num_files = 0;
		
		int frame_rate = sample_rate/(frame_size/sample_size);
		
	
        
		while(running)
		{
			if(all_files_sent)
			{
				synchronized(ss_monitor)
		        {
					try{
						Log.i(TAG, "Waiting for notif");
						ss_monitor.wait();
					}
					catch(InterruptedException e){}
					num_files = MediaRecorderThread.max_file_num;
		        }
				Log.i(TAG, "Got Notif");
			}
			
			// create # of streams and set that to audio_input
			for (int i = last_file_sent; i < num_files; i++) 
			{
				String path = null;
				try {
					Integer file_num = new Integer(i+1);
					path = "/sdcard/file_"+file_num.toString()+".3gp";
					audio_input = new FileInputStream(path);
					payload_type = i+1;
				} catch (FileNotFoundException e2) {					
					e2.printStackTrace();
				}
						
				if (audio_input==null) 
					return;
				
				Log.e(TAG, "Trying to to send RTP packet from File"+path);
				
				byte[] buffer=new byte[frame_size+12];
				RtpPacket rtp_packet=new RtpPacket(buffer,0);
				rtp_packet.setPayloadType(payload_type);      
			    int seqn=0;
			    long time=0;
			    long byte_rate=frame_rate*frame_size;
			    
			    boolean reading=true;
			    
			    Log.i(TAG, "Reading blocks of "+(buffer.length-12)+" bytes");
			    while(reading)
			    {
			    	int num=0;
					try {
						num = audio_input.read(buffer,12,buffer.length-12);
					} catch (IOException e1) {
						e1.printStackTrace();
					}
					Log.i(TAG, "Number of blocks read: "+num);
			    	if(num > 0)
			    	{
			    		rtp_packet.setSequenceNumber(seqn++);
			               rtp_packet.setTimestamp(time);
			               rtp_packet.setPayloadLength(num);
	
			               
			               
			               try {
							rtp_socket.send(rtp_packet);
							Log.i(TAG, "Sent packet of size: "+rtp_packet.getLength());
						} catch (IOException e) {
							Log.i(TAG, "Send failure");
							e.printStackTrace();
						}
			               
			               long frame_time=(num*1000)/byte_rate;
			               time+=frame_time;
			               
			               try {  Thread.sleep(frame_time);  } catch (Exception e) {}
			    	}
			    	else
			    	{
			    		reading=false;
			    		Log.i(TAG, "Error reading from InputStream");
			    	}
			    }//end while reading
				File fileToDelete =new File(path);
                fileToDelete.delete();
			    last_file_sent++;
			} // end-for
			
			all_files_sent =  true;
		} // end-while running
	}

}
