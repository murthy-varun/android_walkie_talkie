package edu.ncsu.ece.walkietalkie;

import java.io.File;
import java.io.IOException;

import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.util.Log;

public class MediaPlayerThread implements Runnable {

	public MediaPlayerThread(Object mpMonitor) {
		super();
		this.mp_monitor = mpMonitor;
	}

	public static boolean sip_start_play = false;
	public static volatile int file_num = 0;
	private static final String TAG = "WalkieTalkieEngine";
	
	Object sr_monitor = new Object();
	Object mp_monitor = new Object();
	private MediaPlayer myMediaPlayer;
	
	@Override
	public void run() {
		boolean isRunning = true;
		
		int last_file_played = 1;
		
		// Start Socket Receiver Thread
		SocketReceiverThread sr_thread = new SocketReceiverThread(9998, sr_monitor);
		Thread thread_recv_sender = new Thread(sr_thread, "Socket-Receiver");
		thread_recv_sender.start();
		
		while(isRunning)
		{
			if(last_file_played > file_num)
			{
				synchronized(sr_monitor)
				{
					try {
						sr_monitor.wait();
					} catch (InterruptedException e) {						
						e.printStackTrace();
					}
				}
			}

			Log.i(TAG, "Last File played"+last_file_played);
			Log.i(TAG, "Highest File written"+file_num);
			String path;				

			while(last_file_played<=file_num)
			{
				
				Integer fno=new Integer(last_file_played);
				path="/sdcard/file_"+ fno.toString()+".3gp";
				myMediaPlayer=new MediaPlayer();
				try {
					myMediaPlayer.setDataSource(path);
				} 
				catch (IllegalArgumentException e) 
				{
					e.printStackTrace();
				} 
				catch (IllegalStateException e) 
				{
					e.printStackTrace();
				}
				catch (IOException e) 
				{
					e.printStackTrace();
				}
				
				try 
				{
					myMediaPlayer.prepare();
				}
				catch (IllegalStateException e) 
				{
					e.printStackTrace();
				}
				catch (IOException e) 
				{
					e.printStackTrace();
				}
				
				myMediaPlayer.start();
				
				while(myMediaPlayer.isPlaying()) {}
				
				myMediaPlayer.setOnCompletionListener(new OnCompletionListener() {
					
					@Override
					public void onCompletion(MediaPlayer mp) {
						myMediaPlayer.stop();
						myMediaPlayer.release();
						myMediaPlayer=null;
					}
				});
				File fileToDelete =new File(path);
                fileToDelete.delete();
				last_file_played++;				
			}		
		}
		
	}

}
