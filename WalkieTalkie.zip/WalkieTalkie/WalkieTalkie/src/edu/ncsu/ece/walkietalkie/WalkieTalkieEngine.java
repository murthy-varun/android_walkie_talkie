package edu.ncsu.ece.walkietalkie;

import java.io.File;

import org.zoolu.sip.provider.SipProvider;
import org.zoolu.sip.provider.SipStack;

//import android.app.AlertDialog;
import android.util.Log;

public class WalkieTalkieEngine{
	
	private static final String TAG = "WalkieTalkieEngine";
	private int m_CurrentState = Constants.INIT;
	
	public static boolean sip_result_success = false;
	private String local_addr;
	
	Object monitor = new Object();	
	Object mr_monitor = new Object();
	Object mp_monitor = new Object();
	
	public static String m_userName;
	public static String m_password;
	public static String m_server_addr;
	public static String m_groupNum;
	
	private String via_addr=null;
	
	/** Register Agent */
	private RegisterAgent ra;
	
	private SipProvider sip_provider; 
		
	/** Size of the buffer */
	public static final int BUFFER_SIZE = 32768;
	
	//AlertDialog m_status = null;
		
	public WalkieTalkieEngine(String local_addr)
	{
		this.local_addr = local_addr;
	}
	
	public int GetState()
	{
		return m_CurrentState;
	}
	
	public void setState(int state) {
		m_CurrentState = state;
	}
	
	public synchronized boolean StartEngine() {
		
		/*
		 * 1. Send SIP register message to the Server.
		 * 2. Handle SIP response (200 OK or any error response) received from SIP server
		 * 3. Mute the Microphone
		 * 4. Move to the next screen i.e. Call screen
		 * 5. Spawn 4 new threads viz. 
		 *        Audio Sender Thread, 
		 *        Socket Sender Thread, 
		 *        Audio Receiver Thread and 
		 *        Socket Receiver Thread. 
		 *    All the threads will be blocked initially (waiting for explicit notifications)
		 * 6. Wait for user input.
		 *    a. If Talk button is pressed in the call screen, send a SIP Notification message to the
                 server. Handle the response received.
                 i. If an ACK is obtained, un-mute the microphone and send notification to Audio Sender Thread.
                 ii. If an NACK is obtained, go back to step 6
              b. If Stop button is pressed in the call screen, send a SIP Notification message to the server.
		 * 7. Go back to step 6
		 */
		
		//clear all files
		File f = new File("/sdcard");
		if (f.isDirectory()) {
		    String[] files = f.list();
		    for (int i = 0; i < files.length; i++) {
		    	if (files[i].contains("file_"))
			      {
					 // Attempt to delete it
		    		String path = "/sdcard/"+files[i];  
					File files_tbd = new File(path);
					files_tbd.delete();
			      }
			}		      
		}


		
		// initialize Sip Stack and the log
		SipStack.init(null);
		
		
		if(local_addr != null)
		{			
			via_addr = local_addr.substring(1);
		}
		else
		{
			via_addr = "192.168.1.5";
		}
		Log.i(TAG, "Local IP address="+via_addr);
		
	
		int port = Constants.UA_SIP_TX_PORT ;
		sip_provider = new SipProvider(via_addr, port);
		//m_CurrentState =Constants.INIT;
		
		return true;
	}
	
	public boolean login()
	{
		String user = m_userName;
		String passwd = m_password;
		String realm = m_server_addr;		
		String from_url = user+"@"+m_server_addr;
		String contact_url =  user+"@"+via_addr+":"+Constants.UA_SIP_TX_PORT;
		ra = new RegisterAgent(sip_provider, from_url, contact_url, user, realm, passwd, monitor);
		
		String user_server=m_userName+"@"+m_server_addr;
		
		sip_result_success = false;
		ra.new_user(user_server, m_password);
		
		synchronized(monitor)
		{				
			try{
				monitor.wait(5000);
			}
			catch(InterruptedException e){}
		}
		// check result
		if (!sip_result_success)
		{
			Log.i(TAG, "SIP Login failed");
			// TODO: Show alert dialog
			return false;
		}
		Log.i(TAG, "SIP Login Successful");
		m_CurrentState = Constants.LOGGED_IN;
		
		MediaRecorderThread mr_thread = new MediaRecorderThread(m_server_addr, mr_monitor);
		Thread media_rec_thread = new Thread(mr_thread,"Media-Recoder");
		media_rec_thread.start();
		
		MediaPlayerThread mp_thread = new MediaPlayerThread(mp_monitor);
		Thread media_player_thread = new Thread(mp_thread, "Media-Player");
		media_player_thread.start();
		
		return true;
	}
	
	public boolean register(int expire_time)
	{
		if(ra == null)
		{
			String user = m_userName;
			String passwd = m_password;
			String realm = m_server_addr;		
			String from_url = user+"@"+m_server_addr;
			String contact_url =  user+"@"+via_addr+":"+Constants.UA_SIP_TX_PORT;
			ra = new RegisterAgent(sip_provider, from_url, contact_url, user, realm, passwd, monitor);
		}
		ra.register(expire_time, m_groupNum);
		
		synchronized(monitor)
		{				
			try{
				monitor.wait(5000);
			}
			catch(InterruptedException e){}
		}
		// check result
		if (!sip_result_success)
		{
			Log.i(TAG, "SIP Registration for "+m_groupNum+" failed");
			// TODO: Show alert dialog
			return false;
		}
		Log.i(TAG, "SIP Registration for "+m_groupNum+" Successful");
		
		if(expire_time != 0)
			m_CurrentState = Constants.REGISTERED;
		else
			m_CurrentState = Constants.LOGGED_IN;
		
		return true;
	}
	
	public boolean bye()
	{
		if(ra == null)
		{
			String user = m_userName;
			String passwd = m_password;
			String realm = m_server_addr;		
			String from_url = user+"@"+m_server_addr;
			String contact_url =  user+"@"+via_addr+":"+Constants.UA_SIP_TX_PORT;
			ra = new RegisterAgent(sip_provider, from_url, contact_url, user, realm, passwd, monitor);
		}
		ra.send_bye(m_userName+"@"+m_server_addr);
		return true;
		
	}
	
	public boolean sipsend() {
			//while(registered)
			// 6. Send SIP option
		if(ra == null)
		{
			String user = m_userName;
			String passwd = m_password;
			String realm = m_server_addr;		
			String from_url = user+"@"+m_server_addr;
			String contact_url =  user+"@"+via_addr+":"+Constants.UA_SIP_TX_PORT;
			ra = new RegisterAgent(sip_provider, from_url, contact_url, user, realm, passwd, monitor);
		}
		
		ra.send_option(Constants.TALK);
		//Wait for response from SIP server		
		synchronized(monitor)
		{				
			try{
				monitor.wait(5000);
			}
			catch(InterruptedException e){}
		}
		// check result
		if (!sip_result_success)
		{
			Log.i(TAG, "SIP Option: TALK unsuccessful");
			//TODO: Send Alert on the screen that talk cannot be done
			return false;
		}
		//TODO: Disable talk button and enable stop button
		Log.i(TAG, "SIP Option: TALK successful");
									
		synchronized(mr_monitor){
			MediaRecorderThread.sip_start_record = true;
			mr_monitor.notify();
			
			return true;
		}
	}
	
	public void stopsip() {

		MediaRecorderThread.sip_start_record = false;
		synchronized(mr_monitor){
			mr_monitor.notify();
		}
		
		if(ra == null)
		{
			String user = m_userName;
			String passwd = m_password;
			String realm = m_server_addr;		
			String from_url = user+"@"+m_server_addr;
			String contact_url =  user+"@"+via_addr+":"+Constants.UA_SIP_TX_PORT;
			ra = new RegisterAgent(sip_provider, from_url, contact_url, user, realm, passwd, monitor);
		}
		
		ra.send_option(Constants.END);
		//Wait for response from SIP server		
		synchronized(monitor)
		{				
			try{
				monitor.wait(5000);
			}
			catch(InterruptedException e){}
		}
		// check result
		if (!sip_result_success)
		{
			Log.i(TAG, "SIP Option: END unsuccessful");
			//TODO: Send Alert on the screen that talk cannot be done						
		}
		//TODO: Disable End button and enable Talk button
		Log.i(TAG, "SIP Option: END successful");
		

	}
	
}
