package edu.ncsu.ece.walkietalkie;

import java.io.IOException;

import android.media.MediaRecorder;

public class MediaRecorderThread implements Runnable{

	private static long SLEEP_TIME = 3000;


	public MediaRecorderThread(String serverAddr, Object mrMonitor) {
		super();
		this.server_addr = serverAddr;
		this.mr_monitor = mrMonitor;
	}

	public static boolean sip_start_record = false;
	public static volatile  int max_file_num;
	
	String server_addr;
	Object ss_monitor = new Object();
	Object mr_monitor = new Object();
	private MediaRecorder myMediaRecorder;
	
	
	private void init(String filePath)
	{
		myMediaRecorder=new MediaRecorder();
		myMediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
		myMediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
		myMediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
		myMediaRecorder.setOutputFile(filePath);	
		//this.filePath=filePath;
		
	}
	
	private void begin()
	{
		try {
			myMediaRecorder.prepare();
		} 
		catch (IllegalStateException e) 
		{
			e.printStackTrace();
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		myMediaRecorder.start();		
	}
	
	private void end()
	{
		myMediaRecorder.stop();
		myMediaRecorder.release();
		//myMediaRecorder.reset();
		myMediaRecorder=null;
	}
	
	@Override
	public void run() {
		boolean isRunning = true;
		
		// Start Socket Sender Thread		
		SocketSenderThread ss_thread = new SocketSenderThread(server_addr, 9999, ss_monitor);
		Thread thread_sock_sender = new Thread(ss_thread, "Socket-Sender");
		thread_sock_sender.start();
		int fileno=1;
		android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_AUDIO);
		
		while(isRunning)
		{
			if(!sip_start_record)
			{
				SLEEP_TIME = 2500;
				synchronized(mr_monitor)
				{	
					try{
						mr_monitor.wait();
					}
					catch(InterruptedException e){}
				}
			}
			// Create  Files
			Integer fno=new Integer(fileno);
			String path="/sdcard/file_"+ fno.toString()+".3gp";
			
			init(path);
			begin();
			try 
			{
				Thread.sleep(SLEEP_TIME);
			}
			catch (InterruptedException e) 
			{
				e.printStackTrace();
			}
			end();
			max_file_num=fileno;
			fileno++;
			
			if(SLEEP_TIME < Constants.MAX_REC_TIME)
				SLEEP_TIME += 1000; 
			
			// notify Socket Sender thread
			synchronized(ss_monitor)
			{
				SocketSenderThread.all_files_sent = false;
				ss_monitor.notify();
			}
		}		
	}
}
