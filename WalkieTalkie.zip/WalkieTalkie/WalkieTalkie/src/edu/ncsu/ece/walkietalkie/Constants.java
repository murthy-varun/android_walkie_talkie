
package edu.ncsu.ece.walkietalkie;

public class Constants {
	public static final String TALK="TALK";
	public static final String END="ENDTALK";

	public static final int UA_SIP_TX_PORT = 5071;

	public static final int PKT_SIZE = 500;

	public static final long MAX_REC_TIME = 5000;

	// Walkie-Talkie States
	public static final int INIT = 0;
	public static final int LOGGED_IN = 1;
	public static final int REGISTERED = 2;

	//Activities
	public static final int LOGIN_ACTIVITY = 1;
	public static final int REGISTER_ACTIVITY = 2;
}
