package edu.ncsu.ece.walkietalkie;

import java.io.FileOutputStream;
import java.io.OutputStream;
import java.net.DatagramSocket;
import java.net.SocketException;

import android.util.Log;
import org.hsc.net.RtpPacket;
import org.hsc.net.RtpSocket;


public class SocketReceiverThread implements Runnable{

	public SocketReceiverThread(int port, Object srMonitor) {
		super();
		this.audio_output = null;
		this.port = port;
		this.sr_monitor = srMonitor;
		init();
	}
	
	private void init()
	{
		DatagramSocket src_socket = null;
		try {
			src_socket = new DatagramSocket(port);			
			
			Log.i(TAG, "init:  port: "+port);
			rtp_socket = new RtpSocket(src_socket);
		} 
		catch (SocketException e) {
			Log.i(TAG, "Socket cannot be opened");
			e.printStackTrace();
		}
	}

	/** Size of the read buffer */
	public static final int BUFFER_SIZE=32768;
	
	private static final String TAG = "WalkieTalkieEngine";
	   
	OutputStream audio_output;
	private  int port;
	Object sr_monitor = new Object();
	/** The RtpSocket */
	RtpSocket rtp_socket=null;
	
	@Override
	public void run() {
	   /** Whether it is running */
	   boolean running=true;
	   
	   int file_num = 0;

      if (rtp_socket==null)
      {  
    	  Log.i(TAG, "ERROR: RTP socket is null");
         return;
      }
      
      byte[] buffer=new byte[BUFFER_SIZE];
      RtpPacket rtp_packet=new RtpPacket(buffer,0);
      
      Log.i(TAG, "Reading blocks of max "+buffer.length+" bytes");
      
      try
      {
    	  while(running)
    	  {
    		  try
    		  {
    			  Log.i(TAG, "Waiting for RTP packets");
    			// read a block of data from the rtp socket
                rtp_socket.receive(rtp_packet);
                
                
                int tmp_file_num = rtp_packet.getPayloadType();
                Log.e(TAG, "Received RTP packets of length="+rtp_packet.getLength()+" bytes and file num: "+tmp_file_num);
                
                if((tmp_file_num != file_num))
                {
                	// end previous file
                	if(audio_output != null)
                	{
                		audio_output.close();
                	
                		//	update file_num
                		MediaPlayerThread.file_num = file_num;
                	
                		// Notify the Media Player thread
                		synchronized(sr_monitor)
                		{
                			sr_monitor.notify();
                		}
                	}
                	
                	// create a new file
                	Integer fNum = new Integer(tmp_file_num);
                	String path = "/sdcard/file_"+fNum+".3gp";
                	audio_output = new FileOutputStream(path);
                	
                	
                	file_num = tmp_file_num;
                	 
                	
                	
                }
                
                // write this block to the output_stream (only if still running..)
                if (running) audio_output.write(rtp_packet.getPacket(), rtp_packet.getHeaderLength(), rtp_packet.getPayloadLength());
    		  }
    		  catch(java.io.InterruptedIOException e){}
    	  }
      }
      catch(Exception e){ running = false; e.printStackTrace(); }
		
	}

}
