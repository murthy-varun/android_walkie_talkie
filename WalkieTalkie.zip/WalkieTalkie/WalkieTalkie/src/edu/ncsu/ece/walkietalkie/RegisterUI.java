package edu.ncsu.ece.walkietalkie;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

public class RegisterUI extends Activity {

	Spinner m_groupNum;	
	Button m_ok;
	
	@SuppressWarnings("unchecked")
	protected void onCreate(Bundle icicle) {
		super.onCreate(icicle);
		this.setContentView(R.layout.register);
		
		m_groupNum = (Spinner) findViewById(R.id.txt_groupNum);		
		m_ok = (Button) findViewById(R.id.Ok_1);
		
		ArrayAdapter adapter = ArrayAdapter.createFromResource(
	            this, R.array.Groups, android.R.layout.simple_spinner_item);
	    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
	    m_groupNum.setAdapter(adapter);

		
		m_ok.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				WalkieTalkieEngine.m_groupNum = m_groupNum.getSelectedItem().toString();				
				
				setResult(RESULT_OK);
				finish();
			}
        });
		
	}
}
