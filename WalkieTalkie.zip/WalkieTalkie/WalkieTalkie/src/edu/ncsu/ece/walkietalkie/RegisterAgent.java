package edu.ncsu.ece.walkietalkie;

import org.zoolu.sip.address.NameAddress;
import org.zoolu.sip.address.SipURL;
import org.zoolu.sip.authentication.DigestAuthentication;
import org.zoolu.sip.header.AuthorizationHeader;
import org.zoolu.sip.header.ExpiresHeader;
import org.zoolu.sip.header.StatusLine;
import org.zoolu.sip.header.WwwAuthenticateHeader;
import org.zoolu.sip.message.Message;
import org.zoolu.sip.message.MessageFactory;
import org.zoolu.sip.message.SipMethods;
import org.zoolu.sip.provider.SipProvider;
import org.zoolu.sip.provider.SipStack;
import org.zoolu.sip.transaction.TransactionClient;
import org.zoolu.sip.transaction.TransactionClientListener;

import android.util.Log;

public class RegisterAgent implements TransactionClientListener{

	private static final String TAG = "WalkieTalkieEngine";
	
	public static int statusCode=0;
	
	/** Max number of registration attempts. */
	 static final int MAX_ATTEMPTS=3;

	 /** SipProvider */
	 SipProvider sip_provider;

	 /** User's URI with the fully qualified domain name of the registrar server. */
	 NameAddress target;

	 /** User name. */
	 String username;

	 /** User name. */
	 String realm;

	 /** User's passwd. */
	 String passwd;

	 /** Nonce for the next authentication. */
	 String next_nonce;

	 /** Qop for the next authentication. */
	 String qop;

	 /** User's contact address. */
	 NameAddress contact; 

	 /** Expiration time. */
	 int expire_time;

	 /** Renew time. */
	 int renew_time;

	 /** Whether keep on registering. */
	 boolean loop;

	 /** Number of registration attempts. */
	 int attempts;
	  
	 Object monitor;

	 /** Creates a new RegisterAgent. */
	 public RegisterAgent(SipProvider sip_provider, String target_url, String contact_url, Object monitor)
	 {
		 init(sip_provider,target_url,contact_url);
		 this.monitor = monitor;
	 }
	 
	/** Creates a new RegisterAgent with authentication credentials (i.e. username, realm, and passwd). */
	 public RegisterAgent(SipProvider sip_provider, String target_url, String contact_url, String username, String realm, String passwd, Object monitor)
	 {
		 init(sip_provider,target_url,contact_url);
		 //authentication
		 this.username = username;
		 this.realm = realm;
		 this.passwd = passwd;
		 
		 this.monitor = monitor;
	 }

	 private void init(SipProvider sipProvider, String targetUrl, String contactUrl) 
	 {
	      this.sip_provider=sipProvider;	      
	      this.target=new NameAddress(targetUrl);
	      this.contact=new NameAddress(contactUrl);
	      this.expire_time=SipStack.default_expires;
	      this.renew_time=0;	      
	      
	      // authentication
	      this.username=null;
	      this.realm=null;
	      this.passwd=null;
	      this.next_nonce=null;
	      this.qop=null;
	      this.attempts=0;	      
	 }
	 
     /** Registers with the registrar server for <i>expire_time</i> seconds. */
	 public void register(int expire_time, String group)
     {	     
	     attempts=0;
	     if (expire_time>0) 
	     {
	    	 this.expire_time=expire_time;
	     }
	     
	     Message req=MessageFactory.createRegisterRequest(sip_provider,target,target,contact);
	     req.setExpiresHeader(new ExpiresHeader(String.valueOf(expire_time)));
	      if (next_nonce!=null)
	      {  AuthorizationHeader ah=new AuthorizationHeader("Digest");
	         ah.addUsernameParam(username);
	         ah.addRealmParam(realm);
	         ah.addNonceParam(next_nonce);
	         ah.addUriParam(req.getRequestLine().getAddress().toString());
	         ah.addQopParam(qop);
	         String response=(new DigestAuthentication(SipMethods.REGISTER,ah,null,passwd)).getResponse();
	         ah.addResponseParam(response);
	         req.setAuthorizationHeader(ah);
	         //req.setBody("GROUP1");
	      }
	      if (expire_time>0) 
	      {
	    	  printLog("Registering contact "+contact+" (it expires in "+expire_time+" secs)");
	      }
	      else
	      {
	    	  printLog("Unregistering contact "+contact);
	      }
	      req.setBody(group);
	     
	     
	     TransactionClient t=new TransactionClient(sip_provider,req,this);
	     t.request();
     }
     
     /** Sends SIP options message to the server */
     public void send_option(String option)
     {	     	     
	     SipURL sip_url = new SipURL(target.getAddress().getHost());	     
	     Message req = MessageFactory.createRequest(sip_provider, SipMethods.OPTION, sip_url, target, target, contact, option);	     
	        
	     printLog("Sending Option: "+option+" to server "+sip_url);
	     
	     TransactionClient t=new TransactionClient(sip_provider,req,this);
	     t.request();
     }
     
     /** Sends SIP-BYE message to the server */
     public void send_bye(String user)
     {
	     if(user!=null)
	     {
	    	 SipURL sip_url = new SipURL(target.getAddress().getHost());	     
		     Message req = MessageFactory.createRequest(sip_provider, SipMethods.BYE, sip_url, target, target, contact, user);	     
		        
		     printLog("Sending SIP-Bye to server "+sip_url);
		     
		     TransactionClient t=new TransactionClient(sip_provider,req,this);
		     t.request();
	     }
     }
     
     public void new_user(String username,String password)
     {
    	 String user_info="NEWUSER:"+username+"#"+password;
	     
    	 SipURL sip_url = new SipURL(target.getAddress().getHost());	     
	     Message req = MessageFactory.createRequest(sip_provider, SipMethods.OPTION, sip_url, target, target, contact, user_info);	     
	        
	     printLog("Sending Option NEWUSER: "+user_info+" to server "+sip_url);
	     
	     TransactionClient t=new TransactionClient(sip_provider,req,this);
	     t.request();
     }
        
	   
	// **************** Transaction callback functions *****************
     @Override
	 /** Callback function called when client sends back a failure response. */
    public void onTransFailureResponse(TransactionClient transaction, Message resp)
    {
       Log.e(TAG, "Received a Failure response");
       
       if (transaction.getTransactionMethod().equals(SipMethods.REGISTER))
       {  StatusLine status=resp.getStatusLine();
          int code=status.getCode();
          statusCode = code;
          if (code==401 && attempts<MAX_ATTEMPTS && resp.hasWwwAuthenticateHeader() && resp.getWwwAuthenticateHeader().getRealmParam().equalsIgnoreCase(realm))
          {  attempts++;
             Message req=transaction.getRequestMessage();
             req.setCSeqHeader(req.getCSeqHeader().incSequenceNumber());
             WwwAuthenticateHeader wah=resp.getWwwAuthenticateHeader();
             String qop_options=wah.getQopOptionsParam();
             
             qop=(qop_options!=null)? "auth" : null;
             AuthorizationHeader ah=(new DigestAuthentication(SipMethods.REGISTER,req.getRequestLine().getAddress().toString(),wah,qop,null,username,passwd)).getAuthorizationHeader();
             req.setAuthorizationHeader(ah);
             TransactionClient t=new TransactionClient(sip_provider,req,this);
             t.request();
          }
          else
          {  String result=code+" "+status.getReason();
             printLog("Registration failure: "+result);
             
             WalkieTalkieEngine.sip_result_success = false;
             synchronized(monitor)
      	     {
      	       monitor.notify();
      	     }
          }
       }
       if (transaction.getTransactionMethod().equals(SipMethods.OPTION)) {
    	   printLog("Registration failure: ");
           WalkieTalkieEngine.sip_result_success = false;
           synchronized(monitor)
    	     {
    	       monitor.notify();
    	     }
        }
   } 

	@Override
	public void onTransProvisionalResponse(TransactionClient arg0, Message arg1) {
	}
	
	@Override
	/** Callback function called when client sends back a success response. */
	public void onTransSuccessResponse(TransactionClient transaction, Message resp) 
	{
		Log.i(TAG, "Received a Success response");
		statusCode = resp.getStatusLine().getCode();
		WalkieTalkieEngine.sip_result_success = true;
		
		//StatusLine status = resp.getStatusLine();
		//String result = status.getCode() + " " + status.getReason();
			
		
		synchronized(monitor)
		{
			monitor.notify();
		}
	}

	@Override
	/** Callback function called when client expires timeout. */
	public void onTransTimeout(TransactionClient arg0) {		
	}

	private void printLog(String str) 
	{
		
		Log.i(TAG, "RegisterAgent: "+str);  
	}
	
}
