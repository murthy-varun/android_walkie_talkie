package edu.ncsu.ece.walkietalkie;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class LoginUI extends Activity {

	EditText m_UserName;
	EditText m_password;
	EditText m_serverAddr;
	Button m_ok;
	
	protected void onCreate(Bundle icicle) {
		super.onCreate(icicle);
		this.setContentView(R.layout.user_info_layout);
		
		m_UserName = (EditText) findViewById(R.id.txt_username);
		m_password = (EditText) findViewById(R.id.txt_password);
		m_serverAddr = (EditText) findViewById(R.id.serverAddr);
		m_ok = (Button) findViewById(R.id.Ok);
				
		m_ok.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				
				if((m_UserName.getText().toString()== "") || (m_UserName.getText().toString()== null))
				{
					call_alert("Please enter a valid username.");
				}
				if((m_password.getText().toString()=="") || (m_password.getText().toString()==null)){
					call_alert("Please enter a valid password");
				}
				if((m_serverAddr.getText().toString()=="") || (m_serverAddr.getText().toString()==null)){
					call_alert("Please enter a valid server address");
				}
				WalkieTalkieEngine.m_userName = m_UserName.getText().toString();
				WalkieTalkieEngine.m_password = m_password.getText().toString();
				WalkieTalkieEngine.m_server_addr = m_serverAddr.getText().toString();
				
				setResult(RESULT_OK);
				finish();
			}
        });
		
	}

	protected void call_alert(String s) {
		
		AlertDialog m_login_AlertDlg = new AlertDialog.Builder(this)
		.setMessage(s)
		.setTitle("Walkie Talkie")					
		.setCancelable(true)
		.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
				dialog.cancel();
			}
		})
		.show();
		
	}
}
