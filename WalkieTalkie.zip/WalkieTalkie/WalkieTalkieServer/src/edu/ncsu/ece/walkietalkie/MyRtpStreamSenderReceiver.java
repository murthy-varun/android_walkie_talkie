package edu.ncsu.ece.walkietalkie;
/*
 * Copyright (C) 2005 Luca Veltri - University of Parma - Italy
 * 
 * This source code is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This source code is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this source code; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 * Author(s):
 * Luca Veltri (luca.veltri@unipr.it)
 */



//import local.net.RtpPacket;
//import local.net.RtpSocket;

import java.io.*;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.DatagramSocket;
import java.util.Vector;

import javax.swing.text.Position.Bias;

import local.net.RtpPacket;
import local.net.RtpSocket;

//import local.net.MyRtpPacket;
//import local.net.MyRtpSocket;

/** RtpStreamReceiver is a generic stream receiver.
  * It receives packets from RTP and writes them into an OutputStream.
  */
public class MyRtpStreamSenderReceiver extends Thread
{

    /** Whether working in debug mode. */
   //private static final boolean DEBUG=true;
   public static boolean DEBUG=false;

   /** Size of the read buffer */
   public static final int BUFFER_SIZE=32768;

   /** Maximum blocking time, spent waiting for reading new bytes [milliseconds] */
   public static final int SO_TIMEOUT=200;

   /** The OutputStream */
   OutputStream output_stream=null;

   /** The RtpSocket */
   MyRtpSocket rtpsocket_Reciever=null;
   MyRtpSocket rtpsocket_Sender=null;
   
   /** Whether the socket has been created here */
   //boolean socket_is_local=false;

   /**User-Group Bindings**/
   MyBindingInfo location_service;
   
   /** Whether it is running */
   boolean running=false;

   /**rtp listen port for client/server**/
   int rtpPort;
   
   /** Constructs a RtpStreamReceiver.
     * @param output_stream the stream sink
     * @param local_port the local receiver port */
   public MyRtpStreamSenderReceiver(MyBindingInfo location_service,OutputStream output_stream,int local_port)
   {
	   this.output_stream=output_stream;
	   this.location_service=location_service;
	   this.rtpPort=local_port;
	   try
	   {  
		  DatagramSocket socket_reciever=new DatagramSocket(rtpPort);
		  rtpsocket_Reciever=new MyRtpSocket(socket_reciever);
		  //DatagramSocket socket_sender= new DatagramSocket();
		  //rtpsocket_Sender=new MyRtpSocket(datagram_socket, remote_address, remote_port) 
	   }
	   
	   
	   catch (Exception e) 
	   {  
    	  e.printStackTrace();  
	   }
   }

   /** Whether is running */
   public boolean isRunning()
   {  
	   return running;
   }

   /** Stops running */
   public void halt()
   {  
	   running=false;
   }

   /** Runs it in a new Thread. */
   public void run()
   {
	  InetAddress src; 
      String src_address;
      String src_groupNum;
      Vector<String>userList;
      InetAddress groupMember;

      
	  if (rtpsocket_Reciever==null)
      {  if (DEBUG) println("ERROR: RTP socket is null");
         return;
      }
      //else

      byte[] buffer=new byte[BUFFER_SIZE];
      MyRtpPacket rtp_packet=new MyRtpPacket(buffer,0);
      
      if (DEBUG) println("Reading blocks of max "+buffer.length+" bytes");

      //byte[] aux=new byte[BUFFER_SIZE];
      int pkt_count=0;
      running=true;
      try
      {  
    	  rtpsocket_Reciever.getDatagramSocket().setSoTimeout(SO_TIMEOUT);
    	  while (running)
    	  {  
    		  try
    		  { 
    			  // read a block of data from the rtp socket
    			  rtpsocket_Reciever.receive(rtp_packet);
    			  //if (DEBUG) System.out.print(".");
    			  pkt_count++;
    			  // write this block to the output_stream (only if still running..)
    			  System.out.println("RTP PACKET RECIEVED:"+pkt_count);
    			  byte[] pkt=rtp_packet.getPacket();
    			  int offset=rtp_packet.getHeaderLength();
    			  int len=rtp_packet.getPayloadLength();
               
    			  
    			  src_address=rtpsocket_Reciever.getSourceAddress();
    			  System.out.println("Packet Header Length:"+offset);
    			  System.out.println("Packet Payload Length:"+len);
    			  System.out.println("Packet Src Address:"+src_address);
    			  System.out.println("payload Type"+rtp_packet.getPayloadType());
    			  System.out.println("Packet dest Address:"+rtpsocket_Reciever.getDatagramSocket().getLocalAddress());
    			  
    			  if(location_service.hasUserIP(src_address))
    			  {
    				  src_groupNum=location_service.getGroup(src_address);
    				  if(location_service.isTalkerinGroup(src_address, src_groupNum))
    				  {
    					  userList=location_service.bindTable.get(src_groupNum);
    					  for (int index = 0; index < userList.size(); index++)
    					  {
    						  groupMember=InetAddress.getByName(userList.get(index));
    						  if(userList.get(index).equals(src_address))
    						  {
    							 continue; 
    						  }
    						  DatagramSocket socket_sender= new DatagramSocket();
    						  //rtpsocket_Sender=new MyRtpSocket(socket_sender,groupMember , rtpPort);
    						  rtpsocket_Sender=new MyRtpSocket(socket_sender,groupMember , 9998);
    						  rtpsocket_Sender.send(rtp_packet);
    						  System.out.println("Packet forwarded to GroupMember:"+groupMember.toString());
    						  //DO a send to every user
    					  }
    				  }
    				  //else send a sip error message YOU ARE NOT THE TALKER
    			  }
    			  
    			  
    			  if (running)
    			  {
    				  output_stream.write(rtp_packet.getPacket(), rtp_packet.getHeaderLength(), rtp_packet.getPayloadLength());
    			  }
    			  //running=false;
    			  /*
    			   * TO DO
    			   * 1.Check wither the  
    			   */
                 
               /*if (running)
               {  byte[] pkt=rtp_packet.getPacket();
                  int offset=rtp_packet.getHeaderLength();
                  int len=rtp_packet.getPayloadLength();
                  int pos=0;
                  for (int i=0; i<len; i++)
                  {  int linear=G711.ulaw2linear(pkt[offset+i]);
                     //aux[pos++]=(byte)(linear&0xFF);
                     //aux[pos++]=(byte)((linear&0xFF00)>>8);
                     aux[pos++]=(byte)G711.linear2ulaw(linear);
                  }
                  output_stream.write(aux,0,pos);
               }*/
            }
            catch (java.io.InterruptedIOException e) { }
         }
      }
      catch (Exception e) 
      {  
    	  running=false;  
    	  e.printStackTrace();  
      }

      // close RtpSocket and local DatagramSocket
      DatagramSocket socket=rtpsocket_Reciever.getDatagramSocket();
      rtpsocket_Reciever.close();
      if ( socket!=null)
      {
    	  socket.close();
      }
      
      // free all
      //output_stream=null;
      rtpsocket_Reciever=null;
      
      if (DEBUG) println("rtp receiver terminated");
   }


   /** Debug output */
   private static void println(String str)
   {  System.out.println("RtpStreamReceiver: "+str);
   }
   

   public static int byte2int(byte b)
   {  //return (b>=0)? b : -((b^0xFF)+1);
      //return (b>=0)? b : b+0x100; 
      return (b+0x100)%0x100;
   }

   public static int byte2int(byte b1, byte b2)
   {  	
	   return (((b1+0x100)%0x100)<<8)+(b2+0x100)%0x100; 
   }
}


