package edu.ncsu.ece.walkietalkie;
/*
 * Copyright (C) 2005 Luca Veltri - University of Parma - Italy
 * 
 * This source code is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This source code is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this source code; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 * Author(s):
 * Luca Veltri (luca.veltri@unipr.it)
 */

//package local.net;


import java.net.InetAddress;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.io.IOException;

//import local.net.RtpPacket;

import org.zoolu.tools.Random;


/** RtpSocket implements a RTP socket for receiving and sending RTP packets. 
  * <p> RtpSocket is associated to a DatagramSocket that is used
  * to send and/or receive RtpPackets.
  */
public class MyRtpSocket
{
   /** UDP socket */
   DatagramSocket socket;
        
   /**Source address*/
   String s_addr;
   
   /** Remote address */
   InetAddress r_addr;

   /** Remote port */
   int r_port;

   /** Creates a new RTP socket (only receiver) */ 
   public MyRtpSocket(DatagramSocket datagram_socket)
   {  socket=datagram_socket;
      r_addr=null;
      r_port=0;
      s_addr=null;
   }

   /** Creates a new RTP socket (sender and receiver) */ 
   public MyRtpSocket(DatagramSocket datagram_socket, InetAddress remote_address, int remote_port)
   {  socket=datagram_socket;
      r_addr=remote_address;
      r_port=remote_port;
      s_addr=null;
   }

   /** Returns the RTP DatagramSocket */ 
   public DatagramSocket getDatagramSocket()
   {  return socket;
   }

   /** Receives a RTP packet from this socket */
   public void receive(MyRtpPacket rtpp) throws IOException
   {  
	   
	   DatagramPacket datagram=new DatagramPacket(rtpp.packet,2000);
	   //DatagramPacket datagram=new DatagramPacket(rtpp.getPacket(),rtpp.getLength());
	   socket.receive(datagram);
	   //System.out.println("LENGTH:"+datagram.getLength());
	   //System.out.println("DATA:"+datagram.getData().toString());
      rtpp.packet_len=datagram.getLength();     
      //rtpp.setLength(datagram.getLength()); //=datagram.getLength();
      s_addr=datagram.getAddress().getHostAddress();
      //r_addr=datagram.getSocketAddress().toString();
      //System.out.print("SADDR:"+s_addr.getHostAddress());
   }
   
   /** Sends a RTP packet from this socket */      
   public void send(MyRtpPacket rtpp) throws IOException
   {  	 DatagramPacket datagram=new DatagramPacket(rtpp.packet,rtpp.packet_len);
   		//DatagramPacket datagram=new DatagramPacket(rtpp.getPacket(),rtpp.getLength());
      datagram.setAddress(r_addr);
      datagram.setPort(r_port);
      //s_addr=datagram.getAddress();
      socket.send(datagram);
   }

   public String getSourceAddress()
   {
	   return s_addr;
   }
   /** Closes this socket */      
   public void close()
   {  //socket.close();
   }
}
