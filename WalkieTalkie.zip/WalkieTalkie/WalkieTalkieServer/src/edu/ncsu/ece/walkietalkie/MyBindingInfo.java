/*
 * Copyright (C) 2005 Luca Veltri - University of Parma - Italy
 * 
 * This source code is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This source code is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this source code; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 * Author(s):
 * Luca Veltri (luca.veltri@unipr.it)
 */

package edu.ncsu.ece.walkietalkie;



import java.util.*;


/** LocationServiceImpl is a simple implementation of a LocationService.
  * LocationServiceImpl allows creation and maintainance of a
  * location service for registered users.
  */
public class MyBindingInfo
{
   
	public final int FAILED=0;
	public final int SUCCESSFULL=1;
	public final int DUPLICATE_SAME_GROUP=2;
	public final int DUPLICATE_DIFF_GROUP=3;
		
	private int numGrps;
	/** Users bindings. Set of pairs of { (String)groupNum , (Vector<string>)users }. */
	
	HashMap<String,Vector<String>> bindTable;
	HashMap<String, String> talkFlag;
	HashMap<String,String> usertoGroupMapping;
	
   /** Creates a new MyBindingInfo */
   public MyBindingInfo(int numGrps)
   {  
	   String group;
	   
	   this.numGrps=numGrps;
	   bindTable=new HashMap<String,Vector<String>>(numGrps);
	   usertoGroupMapping=new HashMap<String, String>();
	   talkFlag=new HashMap<String, String>(numGrps);
	   for (int index = 0; index < numGrps; index++)
	   {
		   Integer i=new Integer(index);
		   group="GROUP"+i.toString();
		   System.out.println("group:"+group);
		   addGroup(group);
		   
	   }
   }


   // **************** Methods of interface Registry ****************


   /** Returns the numbers of users in the database.
     * @return the numbers of user entries */
   public synchronized  int size()
   {  
	   return bindTable.size();
   }

   /*
    * add a new group to the table
    * with userList 
    */
   public synchronized int addGroup(String grpNum)
   {
	   if(hasGroup(grpNum))
	   {
		   return FAILED;
	   }
	   Vector<String> userList=new Vector<String>();
	   bindTable.put(grpNum, userList);
	   talkFlag.put(grpNum, null);
	   return SUCCESSFULL;
   }

   
   public synchronized int removeGroup(String grpNum)
   {  

	   if (!hasGroup(grpNum))
	   {
		   return FAILED;
	   }
	   bindTable.remove(grpNum);
	   talkFlag.remove(grpNum);
	   return SUCCESSFULL;
   }

   /** Returns an enumeration of the groups in this database.
     * @return the list of group numbers as an Enumeration of String */
   public synchronized  Set<String> getGroups()
   {  
	   return bindTable.keySet();
   }
   
   
   public synchronized boolean hasGroup(String grpNum)
   {  
	   return (bindTable.containsKey(grpNum));
   }   
   
   /** Whether a userIP is present in the Whole database
     * @param user the user name
     * @return true if the user name is present as key */
   public synchronized boolean hasUserIP(String userIP)
   {  
	   return (usertoGroupMapping.containsKey(userIP));
   }
   
   /** Whether a userIP is present in a particular group number 
    * @param user the user name
    * @return true if the user name is present as key */
  public synchronized boolean hasUserIP(String grpNum,String userIP)
  {  
	  Vector<String>userList;
	  if(!hasGroup(grpNum))
	  {
		  return false;
	  }
	  
	  userList=bindTable.get(grpNum);
	  return (userList.contains(userIP));
  }
   
  public boolean isTalking (String grp)
  {

          return (talkFlag.get(grp)!=null);
  }
      
   /** Adds a new user at the database.
     * @param grpNum the groupNum to add to
     * @param user the userIP
     * @return this object */
   public synchronized int addUserIP(String grpNum,String userIP)
   {  
	  Vector<String> UserList; 
	  String getGroupNum;
	  if (hasUserIP(userIP))
	  {
		 		  
		  getGroupNum=usertoGroupMapping.get(userIP);
		  if(getGroupNum.equals(grpNum))
		  {
			  return DUPLICATE_SAME_GROUP;
		  }
		  {
			  return DUPLICATE_DIFF_GROUP;
		  }		  
	  }      
	  UserList=bindTable.get(grpNum);
	  bindTable.remove(grpNum);
	  UserList.addElement(userIP);
      bindTable.put(grpNum,UserList);      
      usertoGroupMapping.put(userIP, grpNum);
      System.out.println("After Registeration");
      //printMappings();
      print_usertoGroupMapping();
      print_bindingTable();
      return SUCCESSFULL;
   }
      
   /** Removes the user from the database.
     * @param user the user name
     * @return this object */
   public synchronized int removeUserIP(String userIP)
   {  
	   Vector<String> UserList; 
	   String talker;
	   String getGroupNum;
		if (hasUserIP(userIP))
		{
			 getGroupNum=usertoGroupMapping.get(userIP);
			 UserList=bindTable.get(getGroupNum);
			 bindTable.remove(getGroupNum);
			 UserList.removeElement(userIP);
			/* if(UserList.isEmpty())
			 {
				 bindTable.put(getGroupNum,null);
			 }
			 else
			 {
				 bindTable.put(getGroupNum,UserList);
			 }
			 */
			 bindTable.put(getGroupNum,UserList);
			 usertoGroupMapping.remove(userIP);
		     
			 talker=talkFlag.get(getGroupNum);
			 if(talker!=null)
			 {
				 talkFlag.remove(getGroupNum);
				 talkFlag.put(getGroupNum, null);
			 }
			 
			 System.out.println("After UnRegisteration");
		     
		     printMappings();
			 return SUCCESSFULL;
	   }
		return FAILED;
   }
   
  
   /** Removes all users belonging to a group from the database.
    * @param Group Number
    * @return this object */
   public synchronized int removeAllUsers(String grpNum)
   {  
	   Vector<String> UserList; 
	   String user;
	   if (!hasGroup(grpNum))
	   {
		   return FAILED;
	   }

	   UserList=bindTable.get(grpNum);
	   bindTable.remove(grpNum);

	   for (int index = 0; index < UserList.size(); index++)
	   {
		   user=UserList.elementAt(index);
		   usertoGroupMapping.remove(user);
	   }
	   UserList.removeAllElements();
	   bindTable.put(grpNum, null);
	   return SUCCESSFULL;
   }

   /*********
    * TO DO 
    *********/
   /** Gets the String value of this Object.
     * @return the String value */
   public String toString()
   {  /*String str="";
      for (Enumeration i=getUserBindings(); i.hasMoreElements(); )
      {  UserBindingInfo u=(UserBindingInfo)i.nextElement();
         str+=u.toString();
      }
      return str;
   	*/
	   return null;
   }

   public synchronized Vector<String> getAllUserIPs(String grpNum)
   {
	   if(!hasGroup(grpNum))
	   {
		   return null;
	   }
	   return(bindTable.get(grpNum));
   }

  /* 
  public String whoisTalking(String grpNum)
   {
	   if(!hasGroup(grpNum))
	   {
		   return null;
	   }
	   return (talkFlag.get(grpNum));
   }
  */
   public synchronized String getGroup(String userIP)
   {
	   return usertoGroupMapping.get(userIP);
   }
  
   public synchronized String talkerUserGroup(String userIP)
  {
	  String talker=null;
	  String getUserGroup;
	  if(usertoGroupMapping.containsKey(userIP))
	  {
		  getUserGroup=usertoGroupMapping.get(userIP);
		  talker=talkFlag.get(getUserGroup);
	  }
	  return talker;
  }

   public synchronized boolean isTalkerinGroup(String userIP,String GroupNum)
   {
	   String talker;
	   talker=talkFlag.get(GroupNum);
	   if(talker!=null && talker.equals(userIP))
	   {
		   return true;
	   }
	   return false;
   }
   
/*   public boolean stoppedTalking(String grpNum, String userIP)
   {
	   if(!hasGroup(grpNum) || !hasUserIP(grpNum, userIP))
	   {
		   return false;
	   }
	   
	   if(talkFlag.get(grpNum).equals(userIP))
	   {
		   talkFlag.remove(grpNum);
		   talkFlag.put(grpNum, null);
		   return true;
	   }
	   return false;
   }
*/   
   public synchronized int endTalking(String userIP)
   {
	   String talker=null;
	   String getUserGroup;
	   if(usertoGroupMapping.containsKey(userIP))
	   {
		   getUserGroup=usertoGroupMapping.get(userIP);
		   talker=talkFlag.get(getUserGroup);
		   if(talker.equals(userIP))
		   {
			   talkFlag.remove(getUserGroup);
			   talkFlag.put(getUserGroup, null);
			   print_talkFlags();
			   return SUCCESSFULL;
		   }
	   }
	   return FAILED;
   }
   
/*   public boolean startedTalking(String grpNum,String userIP)
  {
	   if(!hasGroup(grpNum) || !hasUserIP(grpNum, userIP))
	   {
		   return false;
	   }
	   if(talkFlag.get(grpNum)==null)
	   {
		   talkFlag.remove(grpNum);
		   talkFlag.put(grpNum, userIP);
		   return true;
	   }
	   return false;
   }
*/
   public synchronized int startedTalking(String userIP)
   {
	   String talker=null;
	   String getUserGroup;
	   if(usertoGroupMapping.containsKey(userIP))
	   {
		   getUserGroup=usertoGroupMapping.get(userIP);
		   talker=talkFlag.get(getUserGroup);
		   if(talker==null)
		   {
			   talkFlag.remove(getUserGroup);
			   talkFlag.put(getUserGroup, userIP);
			   print_talkFlags();
			   return SUCCESSFULL;
		   }
	   }
	   return FAILED;
   }
   
   private synchronized void print_usertoGroupMapping()
   {
	   Iterator<String> iterator = usertoGroupMapping.keySet().iterator();  
	   String username;
	   String groupname;
	   System.out.println("************************");
	   System.out.println("MAPPING user to group");
	   while (iterator.hasNext()) 
	   {  
	      username = iterator.next().toString();  
	      groupname = usertoGroupMapping.get(username).toString();  
	      
	      System.out.println(username + " : " + groupname);  
	   }
   }
   
   public synchronized void printMappings()
   {
	   print_usertoGroupMapping();
	   print_bindingTable();
	   print_talkFlags();
   }


   private synchronized void print_talkFlags() 
   {
	   Iterator<String> iterator = talkFlag.keySet().iterator();  
	   String groupname;
	   String username;
	   System.out.println("************************");
	   System.out.println("Group: Talker");
	   while (iterator.hasNext()) 
	   {  
		  groupname = iterator.next().toString();  
	      
		  username = talkFlag.get(groupname);  
	      if(username!=null)
	      {
	    	  System.out.println( groupname+ " : " + username);  
	      }
	      else
	      {
	    	  System.out.println( groupname+ " : ");  
	      }
	   }
	   
	   
	   System.out.println("************************");
   }


private synchronized void print_bindingTable() 
   {
	   Iterator<String> iterator = bindTable.keySet().iterator();
	   //Iterator<String> iterator = usertoGroupMapping.keySet().iterator();  
	   String groupname;
	   Vector<String> users;
	   String username;
	   System.out.println("************************");
	   System.out.println("Binding Table");
	   while (iterator.hasNext()) 
	   {  
	      groupname = iterator.next().toString();  
	     // System.out.print(groupname+" : ");
	    	  username = bindTable.get(groupname).toString();
		      //users=bindTable.get(groupname);
		      //for (int i = 0; i < users.size(); i++)
		      //{
		    //	  System.out.print(users.elementAt(i)+ ",");
		     // }
	    	  System.out.println( groupname+ " : " + username);  
		     // System.out.println("");
	   }
	   System.out.println("************************");
   }  
}