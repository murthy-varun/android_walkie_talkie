package edu.ncsu.ece.walkietalkie;
/*
 * Copyright (C) 2005 Luca Veltri - University of Parma - Italy
 * 
 * This source code is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This source code is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this source code; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 * Author(s):
 * Luca Veltri (luca.veltri@unipr.it)
 */

//package local.server;


import org.zoolu.net.SocketAddress;
import org.zoolu.sip.address.*;
import org.zoolu.sip.provider.*;
import org.zoolu.sip.header.FromHeader;
import org.zoolu.sip.header.SipHeaders;
import org.zoolu.sip.header.Header;
import org.zoolu.sip.header.ToHeader;
import org.zoolu.sip.header.ViaHeader;
import org.zoolu.sip.header.ExpiresHeader;
import org.zoolu.sip.header.StatusLine;
import org.zoolu.sip.header.ContactHeader;
import org.zoolu.sip.header.MultipleHeader;
import org.zoolu.sip.header.WwwAuthenticateHeader;
import org.zoolu.sip.header.AuthorizationHeader;
import org.zoolu.sip.header.AuthenticationInfoHeader;
import org.zoolu.sip.transaction.TransactionServer;
import org.zoolu.sip.message.Message;
import org.zoolu.sip.message.MessageFactory;
import org.zoolu.sip.message.SipResponses;
import org.zoolu.tools.Parser;
import org.zoolu.tools.LogLevel;
import org.zoolu.tools.DateFormat;
import edu.ncsu.ece.walkietalkie.MyBindingInfo;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Date;
//import java.util.Locale;
//import java.text.DateFormat;
//import java.text.SimpleDateFormat;
import java.util.Vector;
import java.util.Enumeration;

import local.server.*;
//import local.server.ServerEngine;



/** Class MyServer implements a Registrar SIP Server.
  * It extends class ServerEngine.
  */
public class MyServer extends ServerEngine
{   
	String userIP;
	String userGroup;	
	
	/** LocationService. */
   protected MyBindingInfo location_service;

   /** AuthenticationService (i.e. the repository with authentication credentials). */
   protected MyAuthenticationService authentication_service;

   /** AuthenticationServer. */
   protected MyAuthenticationServer as;

   protected static final String[] GROUP_IDS={"group-1","group-2","group-3","group-4","group-5"};
   
   /** List of already supported location services */
   protected static final String[] LOCATION_SERVICES={ "local", "ldap" };
   /** List of location service Classes (ordered as in <i>LOCATION_SERVICES</i>) */
   protected static final String[] LOCATION_SERVICE_CLASSES={ "local.server.LocationServiceImpl", "local.ldap.LdapLocationServiceImpl" };

   /** List of already supported authentication services */
   protected static final String[] AUTHENTICATION_SERVICES={ "local", "ldap" };
   /** List of authentication service Classes (ordered as in <i>AUTHENTICATION_SERVICES</i>) */
   protected static final String[] AUTHENTICATION_SERVICE_CLASSES={ "local.server.AuthenticationServiceImpl", "local.ldap.LdapAuthenticationServiceImpl" };

   /** List of already supported authentication schemes */
   protected static final String[] AUTHENTICATION_SCHEMES={ "Digest" };
   /** List of authentication server Classes (ordered as in <i>AUTHENTICATION_SCHEMES</i>) */
   protected static final String[] AUTHENTICATION_SERVER_CLASSES={ "local.server.AuthenticationServerImpl" };

   
   /** Constructs a void MyServer. */
   protected MyServer(MyBindingInfo location_service) 
   {
	   this.location_service= location_service;
   }
   
   
   /** Constructs a new MyServer. */
   //public Registrar(SipProvider provider, String db_class, String db_name)
   public MyServer(SipProvider provider, ServerProfile profile,MyBindingInfo location_service)
   {  
	   super(provider,profile);
      printLog("Domains="+getLocalDomains(),LogLevel.HIGH);
	   this.location_service= location_service;

      /* use default location service
      if (location_service==null)
      {
    	  location_service=new MyBindingInfo();   
      }
      */
      printLog("LocationService ("+profile.authentication_service+"): size="+location_service.size()+"\r\n"+location_service.toString(),LogLevel.MEDIUM);

      // authentication server
      if (server_profile.do_authentication || server_profile.do_proxy_authentication)
      {  // first, init the proper authentication service
         String realm=(server_profile.authentication_realm!=null)? server_profile.authentication_realm : sip_provider.getViaAddress();
         
         //using default authentication service
         if (authentication_service==null)
         {
        	 authentication_service=new MyAuthenticationServiceImpl(server_profile.authentication_db);
         }
         printLog("AuthenticationService ("+profile.authentication_service+"): size="+authentication_service.size()+"\r\n"+authentication_service.toString(),LogLevel.MEDIUM);
         
         
         // use default authentication service
        if (as==null) 
        {
        	 as=new MyAuthenticationServerImpl(realm,authentication_service,sip_provider.getLog());
        }
        printLog("AuthenticationServer: scheme: "+profile.authentication_scheme,LogLevel.MEDIUM);
        printLog("AuthenticationServer: realm: "+profile.authentication_realm,LogLevel.MEDIUM);
      }
      else as=null;
   }
 
   
   /** When a new request is received for the local server. */
   public void processRequestToLocalServer(Message msg)
   {  
      
	   printLog("inside processRequestToLocalServer(msg)",LogLevel.MEDIUM);
	   Message resp=null;
	   TransactionServer t=new TransactionServer(sip_provider,msg,null);
	   ToHeader th=msg.getToHeader();
	   if (th==null)  
	   {  
		   printLog("ToHeader missed: message discarded",LogLevel.HIGH);
	       int result=400;
	       resp=MessageFactory.createResponse(msg,result,SipResponses.reasonOf(result),null);  
	    }         
	    SipURL dest_uri=th.getNameAddress().getAddress();
	    String user1=dest_uri.getUserName()+"@"+dest_uri.getHost();
	    String user = null;
	    
	    if (msg.hasContactHeader())
	    {
	    	//System.out.println("Contact header");
	        Vector contacts=msg.getContacts().getHeaders();
	        Vector resp_contacts=new Vector();
	        //System.out.print("contact size"+contacts.size()); 
	        for (int i=0; i<contacts.size(); i++)     
	         {  ContactHeader contact_i=new ContactHeader((Header)contacts.elementAt(i));
	            NameAddress name_address=contact_i.getNameAddress();     
	            String url=name_address.getAddress().toString();     
		    	user=name_address.getAddress().getHost().toString();
	            
	            //System.out.println("Contact"+i+":"+user);
	         }
	    }
	    else
	    {
	    	printLog("ContactHeader missed: message discarded",LogLevel.HIGH);
		    int result=400;
		    resp=MessageFactory.createResponse(msg,result,SipResponses.reasonOf(result),null);  
		    t.respondWith(resp);
		    return;
	    }
	    FromHeader fHeader = msg.getFromHeader();
	    if (fHeader==null)  
		{  
	    	printLog("FromHeader missed: message discarded",LogLevel.HIGH);
		    int result=400;
		    resp=MessageFactory.createResponse(msg,result,SipResponses.reasonOf(result),null);  
		}         
	    
	    //SipURL src_uri=fHeader.getNameAddress().getAddress();
	    //String user=src_uri.getHost();
	    
	    userIP=user;
	    //userGroup=msg.getBody();
	    
	    System.out.println("SIP Message recieved from user:"+userIP);
	    //System.out.println("GroupNUM:"+userGroup);

	    
	    if(msg.isRegister())
	    {
	         if (server_profile.do_authentication)
	         {  // check message authentication
	     	    System.out.println("for registering");
	            Message err_resp=as.authenticateRequest(msg);  
	            if (err_resp!=null)
	            {  //System.out.print(c)
	            	t.respondWith(err_resp);
	               return;
	            }
	         }
	         resp=handleRegister_UnRegisterMsg(msg);
	    }
		  
	    else if(msg.isOption())
	    {
    	   resp=handleOptionsMsg(msg);  	  
	    }
	    else if(msg.isBye())
	    {
	    	   resp=handleByeMsg(msg);  	  
	    }
	    else if (!msg.isAck())
	    {  // send a stateless error response
	    	int result=501; // response code 501 ("Not Implemented")
	    	resp=MessageFactory.createResponse(msg,result,SipResponses.reasonOf(result),null);
	    	sip_provider.sendMessage(resp);
	    	return;
	    }     

	  if (resp==null) return;
      
      if (server_profile.do_authentication)
      {  // add Authentication-Info header field
         resp.setAuthenticationInfoHeader(as.getAuthenticationInfoHeader());
      }
      
      t.respondWith(resp);	  
   }


   private Message handleByeMsg(Message msg) 
   {
 	   printLog("inside handleBYEmsg",LogLevel.MEDIUM);
	   MyAuthenticationService res;
	   
 	   Message resp=null;
 	   int resp_num;
 	   String username,password;
	   String data;
	   username=msg.getBody();

  		
	   System.out.println("for user:"+username);
	   
	   
	   
	   int result,result_talk;
	  
	   result=location_service.removeUserIP(userIP);
	   if(result==location_service.SUCCESSFULL)
 	   {
	   	   printLog("user '"+userIP+"' successfully unregistered",LogLevel.HIGH);
 		   resp_num=200;
 		   res=authentication_service.removeUser1(username);
 		   if(res!=null)
 		   {
 			   //authentication_service.sync();
 			   printLog("user '"+username+"' successfully removed from the database",LogLevel.HIGH);
 	 		   resp_num=200;
 	 		   resp=MessageFactory.createResponse(msg,resp_num,SipResponses.reasonOf(resp_num),null);  
 		   }
 		   else
 		   {
 			   printLog("user '"+username+"' could not be removed successfully from databse!",LogLevel.HIGH);
 	 		   resp_num=404;
 	 		   resp=MessageFactory.createResponse(msg,resp_num,SipResponses.reasonOf(resp_num),null);  
 		   }
 	   }
 	   else
 	   {
	   	   printLog("user '"+userIP+"' failed to unregister.",LogLevel.HIGH);
 	 	   resp_num=404;
 		   resp=MessageFactory.createResponse(msg,resp_num,SipResponses.reasonOf(resp_num),null);  
 	   }
	   
	   return resp;
   }


private Message handleRegister_UnRegisterMsg(Message msg) 
   {
	   Message resp=null;
	   userGroup=msg.getBody();
	   System.out.println("REGISTER MESSAGE");
	   System.out.println("for Group:"+userGroup);

	   if (server_profile.is_registrar && msg.isRegister())
	   {  
	      
	       	printLog("11register",LogLevel.MEDIUM);
	       	/*
	       	if (server_profile.do_authentication)
	          {  
	        	  // check message authentication
	        	  Message err_resp=as.authenticateRequest(msg);  
	        	  if (err_resp!=null)
	        	  {  
	        		  //t.respondWith(err_resp);
	            	 resp=err_resp;
	            	 return resp;
	        	  }
	           		printLog("Succefull authentication",LogLevel.MEDIUM);
	          }
	          */
	          int exp_secs=server_profile.expires;
	          // set the expire value
	          ExpiresHeader eh=msg.getExpiresHeader();
	          if (eh!=null)
	          {  
	        	  exp_secs=eh.getDeltaSeconds();
	          }
	          // limit the expire value
	          if (exp_secs<0)
	          {
	        	  exp_secs=0;
	          }
	          else
	          {
	        	  if (exp_secs>server_profile.expires)
	        	  {
	        		  exp_secs=server_profile.expires;
	        	  }
	          }
	          if(exp_secs!=0)
	          {
	        	  printLog("Since exprire time >0 hence Register",LogLevel.MEDIUM);
	        	  resp=updateRegistration(msg);
	          }
	          else
	          {
	        	  printLog("SInce expire time =0 hence UnRegister",LogLevel.MEDIUM);
	        	  resp=updateUnregistration(msg);
	          }
	   	}      
	    return resp;
   }


	private Message updateUnregistration(Message msg) 
	{

		Message resp;
		resp=null;
		int resp_num;
		int result;
		result=location_service.removeUserIP(userIP);
		if(result==location_service.SUCCESSFULL)
	 	{
		   printLog("user '"+userIP+"' successfully unregistered",LogLevel.HIGH);
	 	   resp_num=200;
	 	   resp=MessageFactory.createResponse(msg,resp_num,SipResponses.reasonOf(resp_num),null);  
	 	}
	 	else
	 	{
		   printLog("user '"+userIP+"' failed to unregister.",LogLevel.HIGH);
	 	   resp_num=404;
	 	   resp=MessageFactory.createResponse(msg,resp_num,SipResponses.reasonOf(resp_num),null);  
	 	}
		return resp;
	}


private Message handleOptionsMsg(Message msg) 
   {
	   Message resp=null;
	   System.out.println("OPTIONS MESSAGE");
	   printLog("inside handleOptionsMsg",LogLevel.MEDIUM);
 	   
	   String data;
 	   data=msg.getBody();
 	   
 	   
 	  	if(data.equals("TALK"))
 	  	{
 	  		resp=handleOptionsTALKmsg(msg);
 	  		
 	  	}
 	  	else if(data.equals("ENDTALK"))
 	  	{
 	  		resp=handleOptionsENDTALKmsg(msg);
 	  	}
 	  	else if(data.startsWith("NEWUSER:"))
 	  	{
 	  		resp=handleOptionsNEWUSERmsg(msg);
 	  	}
 	  	return resp;
		
   }
	
	
		private Message handleOptionsNEWUSERmsg(Message msg) 
		{
	 	   printLog("inside handleOptionsNEW USERmsg",LogLevel.MEDIUM);
		   System.out.println("For NEW USER");
		   MyAuthenticationService res;
		   
	 	   Message resp=null;
	 	   int resp_num;
	 	   String username,password;
		   String data;
		   data=msg.getBody();

		   int colon_pos=data.indexOf(':');
		   int hash_pos= data.indexOf('#');
	  		
		   username=data.substring(colon_pos+1, hash_pos);
		   System.out.println("user:"+username);
	  		
		   password=data.substring(hash_pos+1);
		   System.out.println("password"+password);
	  		
		   res=authentication_service.addUser(username, password.getBytes());
		   if(res!=null)
		   {
			   //authentication_service.sync();
			   printLog("user '"+username+"' successfully added to teh databse with password",LogLevel.HIGH);
	 		   resp_num=200;
	 		   resp=MessageFactory.createResponse(msg,resp_num,SipResponses.reasonOf(resp_num),null);  
		   }
		   else
		   {
			   printLog("user '"+username+"' already exsists!",LogLevel.HIGH);
	 		   resp_num=404;
	 		   resp=MessageFactory.createResponse(msg,resp_num,SipResponses.reasonOf(resp_num),null);  
		   }
 		   return resp;
		}		
	  		
		   private Message handleOptionsENDTALKmsg(Message msg) 
		   {
		 	   printLog("inside handleOptionsENDTALKmsg",LogLevel.MEDIUM);
			   System.out.println("to ENDTALK");

		 	   Message resp;
		 	   int resp_num;
		 	   int result;
		 	   boolean istalker;
		 	   
		 	   istalker=location_service.isTalkerinGroup(userIP, userGroup);
		 	   if(istalker==true)
		 	   {
			   	   printLog("user '"+userIP+"' talking stopped successfully",LogLevel.HIGH);
		 		   resp_num=200;
		 		   resp=MessageFactory.createResponse(msg,resp_num,SipResponses.reasonOf(resp_num),null);  
		 	 	   try 
		 	 	   {
					Thread.sleep(2500);
		 	 	   } 
		 	 	   catch (InterruptedException e) 
		 	 	   {
					
					e.printStackTrace();
		 	 	   }
		 		   result=location_service.endTalking(userIP);
		 	   }
		 	   else
		 	   {
			   	   printLog("user '"+userIP+"' wasn't talking.",LogLevel.HIGH);
		 	 	   resp_num=404;
		 		   resp=MessageFactory.createResponse(msg,resp_num,SipResponses.reasonOf(resp_num),null);  
		 	   }
		 	   return resp;
		   }


   private Message handleOptionsTALKmsg(Message msg) 
   {
 	   printLog("inside handleOptionsTALKmsg",LogLevel.MEDIUM);
	   System.out.println("to TALK");

 	   Message resp;
 	   int resp_num;
 	   int result;
 	   result=location_service.startedTalking(userIP);
 	   	   
 	   if(result==location_service.SUCCESSFULL)
 	   {
	   	   printLog("user '"+userIP+"' is allowed to talk.",LogLevel.HIGH);
	   	   resp_num=200;
 		   resp=MessageFactory.createResponse(msg,resp_num,SipResponses.reasonOf(resp_num),null);  
 	   }
 	   else
 	   {
	   	   printLog("user '"+userIP+"' Cannot talk since somebody else is talking.",LogLevel.HIGH);
 		   resp_num=404;
 		   resp=MessageFactory.createResponse(msg,resp_num,SipResponses.reasonOf(resp_num),null);  
 	   }
 	   
	   return resp;
   }


/** When a new request message is received for a local user. */
   public void processRequestToLocalUser(Message msg)
   {  
	   printLog("inside processRequestToLocalUser(msg)",LogLevel.MEDIUM);
      // stateless-response (in order to avoid DoS attacks)
      if (!msg.isAck())
      {
    	  sip_provider.sendMessage(MessageFactory.createResponse(msg,404,SipResponses.reasonOf(404),null));
      }
      else
      {
    	  printLog("message discarded",LogLevel.HIGH);
      }
   }
 
   
   /** When a new request message is received for a remote UA. */
   public void processRequestToRemoteUA(Message msg)
   {  
	   printLog("inside processRequestToRemoteUA(msg)",LogLevel.MEDIUM);
	   // stateless-response (in order to avoid DoS attacks)
	   if (!msg.isAck())
	   {
		   sip_provider.sendMessage(MessageFactory.createResponse(msg,404,SipResponses.reasonOf(404),null));
	   }
	   else
	   {	
		   printLog("message discarded",LogLevel.HIGH);
	   }
   }


   /** When a new response message is received. */
   public void processResponse(Message resp)
   {  
	   printLog("inside processResponse(msg)",LogLevel.MEDIUM);
      // no actions..
	   printLog("message discarded",LogLevel.HIGH);
   }
   
   
   // *********************** protected methods ***********************

   /** Gets the request's targets as Vector of String.
     * @return It returns a Vector of String representing the target URLs. */
/*   protected Vector<String> getTargets(Message msg)
   {  printLog("inside getTargets(msg)",LogLevel.LOW);

      Vector<String> targets=new Vector<String>();
      
      if (location_service==null)
      {  printLog("Location service is not active",LogLevel.HIGH);
         return targets;
      }           

      SipURL request_uri=msg.getRequestLine().getAddress();
      String username=request_uri.getUserName();
      if (username==null)
      {  printLog("no username found",LogLevel.HIGH);
         return targets;
      }
      String user=username+"@"+request_uri.getHost();
      printLog("user: "+user,LogLevel.MEDIUM); 
           
      if (!location_service.hasUser(user))
      {  printLog("user "+user+" not found",LogLevel.HIGH);
         return targets;
      }

      SipURL to_url=msg.getToHeader().getNameAddress().getAddress();
      
      Enumeration e=location_service.getUserContactURLs(user);
      printLog("message targets: ",LogLevel.LOW);  
      for (int i=0; e.hasMoreElements(); i++)
      {  // if exipred, remove the contact url
         String url=(String)e.nextElement();
         if (location_service.isUserContactExpired(user,url))
         {  location_service.removeUserContact(user,url);
            printLog("target"+i+" expired: contact url removed",LogLevel.LOW);
         }
         // otherwise add the url to the target list
         else
         {  targets.addElement(url);
            printLog("target"+i+"="+targets.elementAt(i),LogLevel.LOW);
         }
      }       
      return targets;
   }

*/
   /** Updates the registration of a local user.
     * @return it returns the response message for the registration. */
   protected Message updateRegistration(Message msg)
   {  
	   Message resp;
	   int result,resp_num;
	   printLog("updateRegisteration",LogLevel.MEDIUM);
	  
	   if (server_profile.register_new_users)
	   {  
		   if(location_service.isTalking(userGroup)) {
               printLog("group " +userGroup+" has a user talking, hence the registration failed", LogLevel.HIGH);
               resp_num=404;
                   resp=MessageFactory.createResponse(msg,resp_num,SipResponses.reasonOf(resp_num),null);
                   return resp;
           }
		   	result=location_service.addUserIP(userGroup, userIP);
		   	if(result==location_service.DUPLICATE_SAME_GROUP)
		   	{
		   	   printLog("user '"+userIP+"' already registered for the same group.",LogLevel.HIGH);
		       resp_num=404;
		       resp=MessageFactory.createResponse(msg,resp_num,SipResponses.reasonOf(resp_num),null);  
		   	}
		    else if(result==location_service.DUPLICATE_DIFF_GROUP)
		    {
		    	printLog("user '"+userIP+"' already registered for a different group.",LogLevel.HIGH);
		    	resp_num=404;
		    	resp=MessageFactory.createResponse(msg,resp_num,SipResponses.reasonOf(resp_num),null);   	
		    }
		    else 
		    {
		        printLog("new user '"+userIP+"' added to group num '"+userGroup+"'",LogLevel.HIGH);
		    	resp_num=200;
		    	resp=MessageFactory.createResponse(msg,resp_num,SipResponses.reasonOf(resp_num),null);  
		    }
	   } 
	   else
	   {  
		   printLog("user '"+userIP+"' unknown: message discarded.",LogLevel.HIGH);
	       resp_num=404;
	       resp= MessageFactory.createResponse(msg,resp_num,SipResponses.reasonOf(resp_num),null);  
	   }
      return resp;
   }


   
   
   // ****************************** Logs *****************************

   
   
   /** Adds a new string to the default Log. */
   private void printLog(String str, int level)
   {  if (log!=null) log.println("Registrar: "+str,level+SipStack.LOG_LEVEL_UA);  
   }

   /** Adds the Exception message to the default Log */
  /* private final void printException(Exception e, int level)
   {  if (log!=null) log.printException(e,level+SipStack.LOG_LEVEL_UA);
   }
  */

   
   
   
   
   
   private static void sipServer(MyBindingInfo location_service, String file) 
   {
		SipStack.init(file);
		SipProvider sip_provider=new SipProvider(file);
		ServerProfile server_profile=new ServerProfile(file);
		new MyServer(sip_provider,server_profile,location_service);
   }   

   private static void rtpServer(MyBindingInfo location_service,String rtpFile, int rtpPort) 
   {
   		try
   		{
   		   MyRtpStreamSenderReceiver senderReciever = null;    
   		   File file=new File(rtpFile);
           FileOutputStream output_stream=new FileOutputStream(file);
           senderReciever=new MyRtpStreamSenderReceiver(location_service,output_stream,rtpPort);
           senderReciever.start();

           System.out.println("Press 'Return' to stop");
           System.in.read();
           senderReciever.halt();
   		}
   		catch (Exception e)
   		{
   			e.printStackTrace();
   		}
   }

   // ****************************** SERVER MAIN *****************************

   /** The main method. */
   public static void main(String[] args)
   {  
	   int NUMBER_OF_GROUPS=5;
	   String sipFile=null;
	   String rtpFile=null;
	   int rtpPort = 0;
	   
	   MyBindingInfo location_service=new MyBindingInfo(NUMBER_OF_GROUPS);   
      
	   for (int i=0; i<args.length; i++)
	   {  
		   
		   if (i==0)
	       {  
			   	rtpPort=Integer.parseInt(args[i]);
	            continue;
	       }
	         
	       if (args[i].equals("-sipfile") && args.length>(i+1))
		   {  
			   sipFile=args[++i];
			   continue;
		   }
		   
		   if (args[i].equals("-rtpfile") && args.length>(i+1))
		   {  
			   rtpFile=args[++i];
			   continue;
		   }
		   
		   if (args[i].equals("-h"))
		   {  
			   System.out.println("usage:\n java MyServer <rtp_local_port> -sipfile <config_file> -rtpfile <audio_file> [-h]\n");
		       System.out.println("   -h               			this help");
		       System.out.println("   rtp_local_port   			port for the rtp");
		       System.out.println("   -sipFile <Config file>  	Sip server Config file");
		       System.out.println("   -rtpFile <audio_file>  	records to audio file");
		       System.exit(0);
		   }
	   }
       
	   
	   sipServer(location_service, sipFile);
      
	   System.out.println("SIP INIT Done..starting RTP thread now");
	   	   
	   rtpServer(location_service, rtpFile, rtpPort);
   }





}